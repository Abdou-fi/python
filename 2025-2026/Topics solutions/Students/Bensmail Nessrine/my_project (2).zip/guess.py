import random

# Define range
lower_bound = 1
upper_bound = 100
secret_number = random.randint(lower_bound, upper_bound)

print(f"Guess a number between {lower_bound} and {upper_bound}.")

while True:
    guess = int(input("Enter your guess: "))
    
    if guess < secret_number:
        print("Too low! Try a higher number.")
    elif guess > secret_number:
        print("Too high! Try a lower number.")
    else:
        print("Congratulations! You guessed it right!")
        break